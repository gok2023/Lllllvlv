# Home Screen Sections 简体中文扩展版

基于 [Home Screen Sections 3.0.4.0](https://github.com/IAmParadox27/jellyfin-plugin-home-sections/releases/tag/3.0.4.0)，面向 Jellyfin 10.11.11。保留上游 GPL-3.0 许可及作者署名。上游源码快照对应 288a1f6ae7a9af3e4ac0d145b6285d84888d0ab1。

## 安装与配置

从 GitHub Releases 下载对应安装包。停止 Jellyfin，备份现有 Home Screen Sections 插件目录及其配置 XML，然后用发行包里的 DLL 替换插件目录里的同名文件，重启 Jellyfin。沿用与当前服务端兼容的 File Transformation 和 Plugin Pages。

在控制台的 Home Screen Sections 栏目设置中打开「媒体库最近添加」，按需启用「合并所有媒体库」并选择「竖版」。开关默认关闭。当前用户需在 Modular Home 中启用模块化首页。安装后如浏览器仍显示旧页面，请强制刷新。

## 本地构建

使用 .NET 9 SDK。将下面的路径换成 Jellyfin 10.11.11 安装目录中存放服务端 DLL 的目录。

~~~powershell
dotnet build src/Jellyfin.Plugin.HomeScreenSections/Jellyfin.Plugin.HomeScreenSections.csproj -c Release -p:JellyfinVersion=10.11.11 -p:JellyfinReferenceDir=D:/TOOL/jellyfin/server
~~~

构建输出位于插件项目的 bin/Release/net9.0。发布时将已验证的安装包上传到新的 GitHub Release。以标签区分本地迭代，插件程序集版本仍沿用 3.0.4.0。

## 版本与回滚

- upstream-3.0.4.0 为上游基线。
- v3.0.4.0-zh.1 为首版中文字资源包。
- v3.0.4.0-zh.2 为加入混合最近添加的中文扩展版。

只想恢复分栏时，关闭「合并所有媒体库」即可。需要回滚插件时，停止 Jellyfin，从对应 GitHub Release 下载旧包并恢复 DLL，再启动服务。运行配置和账号数据由本机管理。
