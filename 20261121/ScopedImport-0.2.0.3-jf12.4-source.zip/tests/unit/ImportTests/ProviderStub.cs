#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using MediaBrowser.Controller.Providers;
using MediaBrowser.Controller.Entities.Movies;
public sealed class ProviderStub : IProviderManager {
public int Selections;
public List<Guid> Refreshed = [];
public Func<MediaBrowser.Controller.Entities.BaseItem, MetadataRefreshOptions, System.Threading.CancellationToken,
    System.Threading.Tasks.Task<MediaBrowser.Controller.Library.ItemUpdateType>> Refresh;

public IMetadataProvider<Movie>[] Selected = [];
public void QueueRefresh(System.Guid @itemId,MediaBrowser.Controller.Providers.MetadataRefreshOptions @options,MediaBrowser.Controller.Providers.RefreshPriority @priority) => throw new Exception("Unexpected provider call: QueueRefresh");
public System.Threading.Tasks.Task RefreshFullItem(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Controller.Providers.MetadataRefreshOptions @options,System.Threading.CancellationToken @cancellationToken) => throw new Exception("Unexpected provider call: RefreshFullItem");
public System.Threading.Tasks.Task<MediaBrowser.Controller.Library.ItemUpdateType> RefreshSingleItem(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Controller.Providers.MetadataRefreshOptions @options,System.Threading.CancellationToken @cancellationToken) {
    Refreshed.Add(item.Id);
    if (options.MetadataRefreshMode != MetadataRefreshMode.None || options.ImageRefreshMode != MetadataRefreshMode.FullRefresh
        || options.ReplaceAllMetadata || options.ReplaceAllImages || options.RemoveOldMetadata) throw new Exception("Unsafe refresh options");
    return Refresh?.Invoke(item, options, cancellationToken) ?? System.Threading.Tasks.Task.FromResult(MediaBrowser.Controller.Library.ItemUpdateType.None);
}
public System.Threading.Tasks.Task SaveImage(MediaBrowser.Controller.Entities.BaseItem @item,System.String @url,MediaBrowser.Model.Entities.ImageType @type,System.Nullable<System.Int32> @imageIndex,System.Threading.CancellationToken @cancellationToken) => throw new Exception("Unexpected provider call: SaveImage");
public System.Threading.Tasks.Task SaveImage(MediaBrowser.Controller.Entities.BaseItem @item,System.IO.Stream @source,System.String @mimeType,MediaBrowser.Model.Entities.ImageType @type,System.Nullable<System.Int32> @imageIndex,System.Threading.CancellationToken @cancellationToken) => throw new Exception("Unexpected provider call: SaveImage");
public System.Threading.Tasks.Task SaveImage(MediaBrowser.Controller.Entities.BaseItem @item,System.String @source,System.String @mimeType,MediaBrowser.Model.Entities.ImageType @type,System.Nullable<System.Int32> @imageIndex,System.Nullable<System.Boolean> @saveLocallyWithMedia,System.Threading.CancellationToken @cancellationToken) => throw new Exception("Unexpected provider call: SaveImage");
public System.Threading.Tasks.Task SaveImage(System.IO.Stream @source,System.String @mimeType,System.String @path) => throw new Exception("Unexpected provider call: SaveImage");
public void AddParts(System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IImageProvider> @imageProviders,System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IMetadataService> @metadataServices,System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IMetadataProvider> @metadataProviders,System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Library.IMetadataSaver> @metadataSavers,System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IExternalId> @externalIds,System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IExternalUrlProvider> @externalUrlProviders) => throw new Exception("Unexpected provider call: AddParts");
public System.Threading.Tasks.Task<System.Collections.Generic.IEnumerable<MediaBrowser.Model.Providers.RemoteImageInfo>> GetAvailableRemoteImages(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Model.Providers.RemoteImageQuery @query,System.Threading.CancellationToken @cancellationToken) => throw new Exception("Unexpected provider call: GetAvailableRemoteImages");
public System.Collections.Generic.IEnumerable<MediaBrowser.Model.Providers.ImageProviderInfo> GetRemoteImageProviderInfo(MediaBrowser.Controller.Entities.BaseItem @item) => throw new Exception("Unexpected provider call: GetRemoteImageProviderInfo");
public System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IImageProvider> GetImageProviders(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Controller.Providers.ImageRefreshOptions @refreshOptions) => throw new Exception("Unexpected provider call: GetImageProviders");
public System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Providers.IMetadataProvider<T>> GetMetadataProviders<T>(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Model.Configuration.LibraryOptions @libraryOptions) where T : MediaBrowser.Controller.Entities.BaseItem { Selections++; return Selected.Cast<IMetadataProvider<T>>().ToArray(); }
public System.Collections.Generic.IEnumerable<MediaBrowser.Controller.Library.IMetadataSaver> GetMetadataSavers(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Model.Configuration.LibraryOptions @libraryOptions) => throw new Exception("Unexpected provider call: GetMetadataSavers");
public MediaBrowser.Model.Configuration.MetadataPluginSummary[] GetAllMetadataPlugins() => throw new Exception("Unexpected provider call: GetAllMetadataPlugins");
public System.Collections.Generic.IEnumerable<MediaBrowser.Model.Providers.ExternalUrl> GetExternalUrls(MediaBrowser.Controller.Entities.BaseItem @item) => throw new Exception("Unexpected provider call: GetExternalUrls");
public System.Collections.Generic.IEnumerable<MediaBrowser.Model.Providers.ExternalIdInfo> GetExternalIdInfos(MediaBrowser.Model.Entities.IHasProviderIds @item) => throw new Exception("Unexpected provider call: GetExternalIdInfos");
public System.Threading.Tasks.Task SaveMetadataAsync(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Controller.Library.ItemUpdateType @updateType) => throw new Exception("Unexpected provider call: SaveMetadataAsync");
public System.Threading.Tasks.Task SaveMetadataAsync(MediaBrowser.Controller.Entities.BaseItem @item,MediaBrowser.Controller.Library.ItemUpdateType @updateType,System.Collections.Generic.IEnumerable<System.String> @savers) => throw new Exception("Unexpected provider call: SaveMetadataAsync");
public MediaBrowser.Model.Configuration.MetadataOptions GetMetadataOptions(MediaBrowser.Controller.Entities.BaseItem @item) => throw new Exception("Unexpected provider call: GetMetadataOptions");
public System.Threading.Tasks.Task<System.Collections.Generic.IEnumerable<MediaBrowser.Model.Providers.RemoteSearchResult>> GetRemoteSearchResults<TItemType,TLookupType>(MediaBrowser.Controller.Providers.RemoteSearchQuery<TLookupType> @searchInfo,System.Threading.CancellationToken @cancellationToken) where TItemType : MediaBrowser.Controller.Entities.BaseItem,new() where TLookupType : MediaBrowser.Controller.Providers.ItemLookupInfo => throw new Exception("Unexpected provider call: GetRemoteSearchResults");
public System.Collections.Generic.HashSet<System.Guid> GetRefreshQueue() => throw new Exception("Unexpected provider call: GetRefreshQueue");
public void OnRefreshStart(MediaBrowser.Controller.Entities.BaseItem @item) => throw new Exception("Unexpected provider call: OnRefreshStart");
public void OnRefreshProgress(MediaBrowser.Controller.Entities.BaseItem @item,System.Double @progress) => throw new Exception("Unexpected provider call: OnRefreshProgress");
public void OnRefreshComplete(MediaBrowser.Controller.Entities.BaseItem @item) => throw new Exception("Unexpected provider call: OnRefreshComplete");
public System.Nullable<System.Double> GetRefreshProgress(System.Guid @id) => throw new Exception("Unexpected provider call: GetRefreshProgress");
public event System.EventHandler<Jellyfin.Data.Events.GenericEventArgs<MediaBrowser.Controller.Entities.BaseItem>> RefreshStarted { add {} remove {} }
public event System.EventHandler<Jellyfin.Data.Events.GenericEventArgs<MediaBrowser.Controller.Entities.BaseItem>> RefreshCompleted { add {} remove {} }
public event System.EventHandler<Jellyfin.Data.Events.GenericEventArgs<System.Tuple<MediaBrowser.Controller.Entities.BaseItem,System.Double>>> RefreshProgress { add {} remove {} }
}
