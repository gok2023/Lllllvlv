﻿using Jellyfin.Plugin.HomeScreenSections.Configuration;
using Jellyfin.Plugin.HomeScreenSections.Helpers;
using Jellyfin.Plugin.HomeScreenSections.Library;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model;
using MediaBrowser.Model.Plugins;
using MediaBrowser.Model.Querying;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Jellyfin.Plugin.HomeScreenSections.Services;

namespace Jellyfin.Plugin.HomeScreenSections.Controllers
{
    /// <summary>
    /// API controller for Modular Home plugin.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ModularHomeViewsController : ControllerBase
    {
        private readonly ILogger<ModularHomeViewsController> m_logger;
        private readonly IHomeScreenManager m_homeScreenManager;
        private readonly ITranslationManager m_translationManager;
        private readonly IUserManager m_userManager;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="logger">Instance of <see cref="ILogger"/> interface.</param>
        /// <param name="homeScreenManager">Instance of <see cref="IHomeScreenManager"/> interface.</param>
        /// <param name="translationManager">Instance of <see cref="ITranslationManager"/> interface.</param>
        /// <param name="userManager">Instance of <see cref="IUserManager"/> interface.</param>
        public ModularHomeViewsController(ILogger<ModularHomeViewsController> logger, IHomeScreenManager homeScreenManager, ITranslationManager translationManager, IUserManager userManager)
        {
            m_logger = logger;
            m_homeScreenManager = homeScreenManager;
            m_translationManager = translationManager;
            m_userManager = userManager;
        }

        /// <summary>
        /// Get the view for the plugin.
        /// </summary>
        /// <param name="viewName">The view identifier.</param>
        /// <returns>View.</returns>
        [HttpGet("{viewName}")]
        [Authorize]
        public ActionResult GetView([FromRoute] string viewName)
        {
            return ServeView(viewName);
        }

        /// <summary>
        /// Get the section types that are registered in Modular Home.
        /// </summary>
        /// <param name="language">Optional language code for translating section display names.</param>
        /// <returns>Array of <see cref="HomeScreenSectionInfo"/>.</returns>
        [HttpGet("Sections")]
        [Authorize]
        public QueryResult<HomeScreenSectionInfo> GetSectionTypes([FromQuery] string? language = null)
        {
            // Todo add reading whether the section is enabled or disabled by the user.
            List<HomeScreenSectionInfo> items = new List<HomeScreenSectionInfo>();

            IEnumerable<IHomeScreenSection> sections = m_homeScreenManager.GetSectionTypes();

            foreach (IHomeScreenSection section in sections)
            {
                HomeScreenSectionInfo item = section.GetInfo();

                item.ViewMode ??= SectionViewMode.Landscape;
                item.AdminDescription ??= section.AdminDescription;

                if (!string.IsNullOrWhiteSpace(language) && item.DisplayText != null)
                {
                    // Fall back to this section's own display text, not a shared literal.
                    item.DisplayText = m_translationManager.Translate(
                        item.AdminTranslationKey ?? item.Section!, language.Trim(), item.DisplayText, section.TranslationMetadata, preferKey: item.AdminTranslationKey != null);
                }

                items.Add(item);
            }

            return new QueryResult<HomeScreenSectionInfo>(null, items.Count, items);
        }

        /// <summary>
        /// Get the user settings for Modular Home.
        /// </summary>
        /// <param name="userId">The user ID.</param>
        /// <returns><see cref="ModularHomeUserSettings"/>.</returns>
        [HttpGet("UserSettings")]
        [Authorize]
        public ActionResult<ModularHomeUserSettings> GetUserSettings([FromQuery] Guid? userId = null)
        {
            if (!UserAuthorizationHelper.TryGetUserId(User, m_userManager, userId, out Guid authenticatedUserId))
            {
                return Forbid();
            }

            IEnumerable<SectionSettings> defaultEnabledSections =
                HomeScreenSectionsPlugin.Instance.Configuration.SectionSettings.Where(x => x.Enabled);
            IEnumerable<SectionSettings> adminLockedSections =
                HomeScreenSectionsPlugin.Instance.Configuration.SectionSettings.Where(x => !x.AllowUserOverride);
            
            return m_homeScreenManager.GetUserSettings(authenticatedUserId) ?? new ModularHomeUserSettings
            {
                UserId = authenticatedUserId,
                EnabledSections = defaultEnabledSections.Select(x => x.SectionId).ToList(),
                LockedSections = adminLockedSections.Select(x => x.SectionId).ToList(),
                DefaultEnabledSections = defaultEnabledSections.Select(x => x.SectionId).ToList()
            };
        }

        /// <summary>
        /// Get the translation pack for the given language.
        /// </summary>
        /// <param name="language">Language code (e.g. "en", "de").</param>
        /// <returns>Dictionary of translation keys to translated strings.</returns>
        [HttpGet("Translations")]
        [Authorize]
        public ActionResult<IDictionary<string, string>> GetTranslations([FromQuery] string language = "en")
        {
            var translations = m_translationManager.GetTranslationPack(language.Trim());
            return Ok(translations ?? new Dictionary<string, string>());
        }

        /// <summary>
        /// Update the user settings for Modular Home.
        /// </summary>
        /// <param name="obj">Instance of <see cref="ModularHomeUserSettings" />.</param>
        /// <returns>Status.</returns>
        [HttpPost("UserSettings")]
        [Authorize]
        public ActionResult UpdateSettings([FromBody] ModularHomeUserSettings obj)
        {
            if (!UserAuthorizationHelper.TryGetUserId(User, m_userManager, obj.UserId, out Guid authenticatedUserId))
            {
                return Forbid();
            }

            obj.UserId = authenticatedUserId;
            m_homeScreenManager.UpdateUserSettings(authenticatedUserId, obj);

            return Ok();
        }

        private ActionResult ServeView(string viewName)
        {
            if (HomeScreenSectionsPlugin.Instance == null)
            {
                return BadRequest("No plugin instance found");
            }

            IEnumerable<PluginPageInfo> pages = HomeScreenSectionsPlugin.Instance.GetViews();

            if (pages == null)
            {
                return NotFound("Pages is null or empty");
            }

            PluginPageInfo? view = pages.FirstOrDefault(pageInfo => pageInfo?.Name == viewName, null);

            if (view == null)
            {
                return NotFound("No matching view found");
            }

            Stream? stream = HomeScreenSectionsPlugin.Instance.GetType().Assembly.GetManifestResourceStream(view.EmbeddedResourcePath);

            if (stream == null)
            {
                m_logger.LogError("Failed to get resource {Resource}", view.EmbeddedResourcePath);
                return NotFound();
            }

            return File(stream, MimeTypes.GetMimeType(view.EmbeddedResourcePath));
        }
    }
}
