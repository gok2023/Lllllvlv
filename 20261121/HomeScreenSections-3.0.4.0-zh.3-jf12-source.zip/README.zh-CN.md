# Home Screen Sections 简体中文扩展版

基于 [Home Screen Sections 3.0.4.0](https://github.com/IAmParadox27/jellyfin-plugin-home-sections/releases/tag/3.0.4.0)，保留 Jellyfin 10.11.11 构建，并提供适配 Jellyfin 12.4 的独立构建。保留上游 GPL-3.0 许可及作者署名。上游源码快照对应 288a1f6ae7a9af3e4ac0d145b6285d84888d0ab1。

## 安装与配置

从 GitHub Releases 下载对应安装包。停止 Jellyfin，备份现有 Home Screen Sections 插件目录及其配置 XML，然后用发行包里的 DLL 替换插件目录里的同名文件，重启 Jellyfin。沿用与当前服务端兼容的 File Transformation 和 Plugin Pages。

在控制台的 Home Screen Sections 栏目设置中打开「媒体库最近添加」，按需启用「合并所有媒体库」并选择「竖版」。开关默认关闭。当前用户需在 Modular Home 中启用模块化首页。安装后如浏览器仍显示旧页面，请强制刷新。

## 本地构建

10.11.11 使用 .NET 9；12.4 使用 .NET 10。将引用路径换成对应版本官方服务端 DLL 所在目录，不能混用 DLL 或仅修改 targetAbi。

~~~powershell
dotnet build src/Jellyfin.Plugin.HomeScreenSections/Jellyfin.Plugin.HomeScreenSections.csproj -c Release -p:JellyfinVersion=10.11.11 -p:JellyfinReferenceDir=D:/TOOL/jellyfin/server
~~~

12.4 构建命令：

~~~powershell
dotnet build src/Jellyfin.Plugin.HomeScreenSections/Jellyfin.Plugin.HomeScreenSections.csproj -c Release -p:JellyfinVersion=12.4.0 -p:JellyfinReferenceDir=<Jellyfin-12.4-server>
~~~

构建输出分别位于插件项目的 bin/Release/net9.0 或 net10.0。发布时将已验证的安装包上传到新的 GitHub Release。以标签区分本地迭代，插件程序集版本仍沿用 3.0.4.0。

## 版本与回滚

- upstream-3.0.4.0 为上游基线。
- v3.0.4.0-zh.1 为首版中文字资源包。
- v3.0.4.0-zh.2 为加入混合最近添加的 10.11 中文扩展版，旧安装包继续保留。
- v3.0.4.0-zh.3-jf12 为通过用户实际验收的 12.4 混合时间流定制构建，程序集仍为 3.0.4.0。

只想恢复分栏时，关闭「合并所有媒体库」即可。需要回滚插件时，停止 Jellyfin，从对应 GitHub Release 下载旧包并恢复 DLL，再启动服务。运行配置和账号数据由本机管理。

## 12.4 维护结果

复用旧版混合开关、权限/隐藏库过滤、归组、最新符合条件成员的入库时间排序、竖版卡片及汉化。按需分页并处理时间相同的排序边界，先合并/归组/排序再限量，关闭开关恢复原分栏。HSS 混合时间流已通过用户实际使用验收，本轮不重新开发。保留 ElegantFin、原用户栏目顺序及原配置；前端预览沿用 ApiClient 标准认证，不启用旧认证。

安装需使用与当前 Jellyfin 兼容的 File Transformation 与 Plugin Pages。用户启用状态、ModularHomeSettings 和前端/栏目顺序缓存均须保留。Release 的 12.4 DLL 与本机已验收 DLL 的 SHA-256 一致；不把旧版 DLL 复制至新版环境。
